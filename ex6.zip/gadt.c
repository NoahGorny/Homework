/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex6

******************************************/
#include "gadt.h"
#include <stdlib.h>
#include <stdio.h>
// To use booleans more clearly
typedef unsigned char bool;
#define TRUE 1
#define FALSE 0
/*
	A note about memory efficiency- I built a single struct of nodes-
	which means every node contains 6 pointers to all of the functions.
	This is not really needed but I wanted to make it more clear and
	clean instead of having one struct for the head and one for the nodes.
	This way I have easier time clearing the list and I also think this
	is the way you meant we do this mission.
*/
typedef struct SL_S
{
	// The value of the current node
	ELM val;
	// The next node in the list
	struct SL_S* next;

	// Functions used to operate on the struct
	ELM (*create_elm)();
	void (*cpy_elm)(ELM, ELM);
	int (*cmp_elm)(ELM, ELM);
	void (*free_elm)(ELM);
	void (*print_elm)(ELM);
	ELM (*add_elm_to_elm)(ELM, ELM);
} SL_T;

static void SetupSLN(SL_T* newLN, SL_T* oldLN, ELM val);
static SL_T* RealFindElement(HEAD head, ELM node);

/*********
* function name: SLCreate
* The Input: Elm head_val- the first value of the function.
  ELM(*create_elm)()- function used to allocate memory for new elements.
  void(*cpy_elm)(ELM, ELM)- function used to copy elements.
  int(*cmp_elm)(ELM, ELM)- function used to compare between elements.
  void(*free_elm)(ELM)- function used to free elements.
  void(*print_elm)(ELM)- function used to print elements.
  ELM(*add_elm_to_elm)(ELM, ELM)- function used to add one element to another.
* The Output: Returns HEAD head that is the head of the new list.
* The Function operation: Mallocs a space for the new node and setup
  his functions.
*********/
extern HEAD SLCreate(ELM head_val, ELM(*create_elm)(), 
	void(*cpy_elm)(ELM, ELM), int(*cmp_elm)(ELM, ELM), void(*free_elm)(ELM),
	void(*print_elm)(ELM), ELM(*add_elm_to_elm)(ELM, ELM))
{
	// Allocating memory for the new head
	SL_T *head=(SL_T*) malloc(sizeof(SL_T));
	if(head!=NULL)
	{
		// Allocation was succsessful, setup head and his funcs
		head->val=create_elm();
		if(head->val==NULL)
		{
			// Memory bug allocating for val, free head and return null
			free(head);
			return NULL;
		}
		cpy_elm(head->val, head_val);
		head->next=NULL;
		head->create_elm=create_elm;
		head->cpy_elm=cpy_elm;
		head->cmp_elm=cmp_elm;
		head->free_elm=free_elm;
		head->print_elm=print_elm;
		head->add_elm_to_elm=add_elm_to_elm;
	}
	// Return the newly created head
	return (HEAD)head;
}

/*********
* function name: SLDestroy
* The Input: HEAD head of list that we want to destroy
* The Output: Destroys the whole list
* The Function operation: Calls RemoveElement in a loop until the
  list is empty.
*********/
extern void SLDestroy(HEAD head)
{
	while(head!=NULL)
	{
		// Remove the first value out of the list until the list is empty
		SLRemoveElement(&head, ((SL_T*)head)->val);
	}
}

/*********
* function name: SLAddListElement
* The Input: HEAD* head- the pointer to the head of the list, 
  ELM node- the new value to add.
* The Output: Result to know if there was a memory bug or not.
* The Function operation: First it mallocs a space for the new SLN
  and for the new value, then it setup the new list node using SetupSLN.
  Afterwards it checks if the new node is smaller then the head.
  If it is it becomes the new head, else it starts to go through the list
  and check when the new node is smaller then the current->next node.
  When this happens the new node is inserted between the current node
  and his next node. If the new node is the biggest he will be put at the end.
* Efficiency and memory: As can be seen here, instead of sorting the list
  at the end, I chose to insert the elements via Bubble Insertion-
  which means I travel in the list until I find a bigger node, 
  then I insert the new node in the correct place. This is O(n) notation.
*********/
extern RESULT SLAddListElement(HEAD* head, ELM node)
{
	// We create the new SLN that we will add
	SL_T* newLN=malloc(sizeof(SL_T));
	// Runner that will run through the list
	SL_T* runner=(SL_T*)*head;
	// Create new space for the value
	ELM elmVal=runner->create_elm();

	if((elmVal==NULL)||(newLN==NULL))
	{
		// memory bug, free elmVal and newLN and exit
		(runner->free_elm)(elmVal);
		(runner->free_elm)(newLN);
		return outOfMem;
	}
	// Copy the correct value
	runner->cpy_elm(elmVal, node);
	// Setup newLN
	SetupSLN(newLN, runner, elmVal);
	if(runner->cmp_elm(newLN->val, runner->val)<0)
	{
		// newLn is smaller then the head, it becomes the new head
		newLN->next=runner;
		*head=(HEAD)newLN;
		return success;
	}

	while(runner->next!=NULL)
	{
		if(runner->cmp_elm(newLN->val, (runner->next)->val)<0)
		{
			// new is smaller then runner->next, set his next as runner->next
			newLN->next=runner->next;
			// Becomes the new runner->next
			runner->next=newLN;
			return success;
		}
		// Advance runner in the list
		runner=runner->next; 
	}
	// newLN is bigger then anybody, place him as the last node
	runner->next=newLN;
	return success;
}

/*********
* function name: SetupSLN
* The Input: SL_T* newLN to setup, SL_T* oldLN to get the functions from,
  ELM newVal the new val of the node.
* The Output: Setup newLN with all of the functions, his new value
  and NULL as his next.
* The Function operation: Simply setting up each pointer to the right place.
*********/
static void SetupSLN(SL_T* newLN, SL_T* oldLN, ELM newVal)
{
	// Set the val as the value we created
	newLN->val=newVal;
	newLN->next=NULL;
	// Setup the funcs
	newLN->create_elm=oldLN->create_elm;
	newLN->cpy_elm=oldLN->cpy_elm;
	newLN->cmp_elm=oldLN->cmp_elm;
	newLN->free_elm=oldLN->free_elm;
	newLN->print_elm=oldLN->print_elm;
	newLN->add_elm_to_elm=oldLN->add_elm_to_elm;
}

/*********
* function name: SLRemoveElement
* The Input: HEAD* head- the pointer to the head head of the list,
  ELM node- value to remove from the list.
* The Output: Result depending on the outcome- failure if the node does
  not exist, and success if it managed to remove the node.
* The Function operation: First it searches if the node exists in the list,
  if its not it just returns failure. Else it checks if the target is the
  head, if it is it removes the old head and sets the next node as the 
  new head. If its not it runs through the list until it finds the node
  BEFORE the target, then it sets target->next as nodeBefore->next and
  frees the removed value and node.
* Efficiency and memory: I could do this a little more efficiently, but
  this way is easy to understand and is O(n) anyway so I dont think this
  is a big problem.
*********/
extern RESULT SLRemoveElement(HEAD* head, ELM node)
{
	// The target we want to remove
	SL_T* target=RealFindElement(*head, node);
	// Runner used to run through the list
	SL_T* runner=(SL_T*)*head;
	if(target==NULL)
	{
		// There is no such item, return failure
		return failure;
	}
	if(target==runner)
	{
		// Save the next element
		target=runner->next;
		// Free the old head val
		runner->free_elm(runner->val);
		// Free the old head
		free(runner);
		// Set the head as old->next
		*head=target;
		return success;
	}
	while(runner->next!=NULL)
	{
		if(runner->next==target)
		{
			// Save (runner->next)->next
			target=target->next;
			// Free (runner->next)->val
			runner->free_elm((runner->next)->val);
			// Free runner->next himself
			free(runner->next);
			// Set runner->next as old runner->next->next
			runner->next=target;
			return success;
		}	
		// Advance in the list
		runner=runner->next;
	}
	// Should not get here
	return failure;
}

/*********
* function name: SLFindElement
* The Input: HEAD head- the head of the list, ELM node to find in the list.
* The Output: It returns the Elm value of the node found. (why?!)
* The Function operation: Finds the actual SL node using RealFindElement.
  If the element exists it returns its value, Else it returns NULL.
*********/
extern ELM SLFindElement(HEAD head, ELM node)
{
	// Find the currect node
	SL_T* theNode=RealFindElement(head, node);
	if(theNode==NULL)
	{
		// No such node was found
		return NULL;
	}
	// We have found the node!
	return theNode->val;
}

/*********
* function name: RealFindElement
* The Input: HEAD head- the head of the list, ELM node to find in the list.
* The Output: It returns the actual SL node with the value searched for.
* The Function operation: Runs through the list and checks each time
  if the value is equal to the needed value. If it is it returns the
  SL node with this value. If it cant find the element it returns NULL.
* Efficiency and memory: This is a little more efficient because it stops
  searching after it finds out that the wanted value is smaller then the
  current node(Its a sorted list so the values will just get bigger). 
*********/
static SL_T* RealFindElement(HEAD head, ELM node)
{
	// So we dont have to cast all the time
	SL_T* pRunner=(SL_T*)head;
	// Used to store the comparison value
	int cmpValue;

	while(pRunner!=NULL)
	{
		// Save the new comparison value
		cmpValue=pRunner->cmp_elm(node, pRunner->val);
		if(cmpValue==0)
		{
			// We found a node with the same value, return it
			return pRunner;
		}
		else if(cmpValue<0)
		{
			// the wanted value is already smaller
			return NULL;
		}
		// Advance in the list
		pRunner=pRunner->next;
	}
	return NULL;
}

/*********
* function name: SLAddToElement
* The Input: HEAD* head- pointer to the head of the list, 
  ELM toEl- element we want to add to, ELM addEl- value we want to add.
* The Output: Result- failure if toEl doesnt exist in the list.
  outOfMem if there was a memory bug, success if it succseeded.
* The Function operation: It saves toEl in order to save his old value.
  Checks if toEl exists in the list, if not it returns outOfMem and frees.
  Then it adds Elm addEl to toEl and adds a new node to the list containing
  the new value. If it could add it removes the old SL node using the saved
  oldEl in order to remember the old value.
* Efficiency and memory: This function is very efficient because instead
  of simply adding to the element and sorting the whole list, it ADDS
  the new value (O(n)) and then REMOVES the old value (O(n)). Which
  means this is more efficient then sorting the whole list.
* Note: I return result here because: a) toEl may not exist in the list
  so we should alert it to the user. b) I use memory allocations so I need
  to make sure I alert the user if there was a memory bug.
*********/
extern RESULT SLAddToElement(HEAD* head, ELM toEl, ELM addEl)
{
	// To save the results of add, remove
	RESULT res;
	// oldEl to temp save the old element
	ELM oldEl=((SL_T*)*head)->create_elm();
	if(oldEl!=NULL)
	{
		// Setting oldEl up
		((SL_T*)*head)->cpy_elm(oldEl, toEl);
		// Check if the element exist
		if(RealFindElement(*head, toEl)!=NULL)
		{
			// Save the added element
			toEl=((SL_T*)*head)->add_elm_to_elm(toEl, addEl);
			// Add the new element
			res=SLAddListElement(head, toEl);
			if(res==outOfMem)
			{
				// Memory fail while adding, free newNode and return res
				((SL_T*)*head)->free_elm(oldEl);
				return outOfMem;
			}
			// Remove the old element
			res=SLRemoveElement(head, oldEl);
			// Free oldEl as we dont need him anymore
			((SL_T*)*head)->free_elm(oldEl);
			return success;
		}
		// We couldnt find the element, free oldEl
		((SL_T*)*head)->free_elm(oldEl);
		return failure;
	}
	else
	{
		// Memory fail creating oldEl
		return outOfMem;
	}
}

/*********
* function name: PrintList
* The Input: HEAD head- the head of the list we want to print.
* The Output: Prints the whole list.
* The Function operation: Runs through the list and prints each element
  according to the format using print_elm and tabs.
*********/
extern void PrintList(HEAD head)
{
	// To know how many tabs to do
	int counter=0;
	// Index for the for loop
	int i;
	// So we dont have to cast all the time
	SL_T* pRunner=(SL_T*)head;
	while(pRunner!=NULL)
	{
		for(i=0; i<counter; i++)
		{
			printf("\t");
		}
		// Print the current element
		pRunner->print_elm(pRunner->val);
		// Go to the next node
		pRunner=pRunner->next;
		// Increase the counter
		counter++;
	}
}

/*********
* function name: PrintSizeList
* The Input: HEAD head- the head of the list we want to print the size of. 
* The Output: Prints the size of the list.
* The Function operation: Runs through the list and count the number of
  times it advanced. When it reachs the end it prints the counter.
*********/
extern void PrintSizeList(HEAD head)
{
	// To know how many items are there
	int counter=0;
	while(head!=NULL)
	{
		counter++;
		// Advance to the next node
		head=((SL_T*)head)->next;
	}
	// Print the counter at the end
	printf("%d\n", counter);
}
