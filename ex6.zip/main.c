/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex6

******************************************/
#include "gadt.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_STRING_SIZE 15
// To use booleans more clearly
typedef unsigned char bool;
#define TRUE 1
#define FALSE 0

// To help us operate with the position type
typedef struct POS_S
{
	// The coordinates of each element
	int x,y;
}POS_T;

void TheSwitch(HEAD *slHead, char input[2], char type, ELM elm, ELM elm2);
void RecieveElement(ELM buffer, char type);
void RecieveTwoElements(ELM buffer,ELM buffer2, char type);
// Funcs to send to the SL
ELM CreateElmPos();
ELM CreateElmStr();
void CpyElmPos(ELM dest, ELM src);
void CpyElmStr(ELM dest, ELM src);
int CmpElmPos(ELM first, ELM second);
int CmpElmStr(ELM first, ELM second);
void freeElm(ELM elm);
void PrintElmPos(ELM pos);
void PrintElmStr(ELM pos);
ELM AddElmToElmPos(ELM pos1, ELM pos2);
ELM AddElmToElmStr(ELM str1, ELM str2);

/*********
* function name: main
* The Input: None
* The Output: This is the main of ex6.
* The Function operation: Asks for the first input and setup slHead
  accordinly. Afterwards it loops by recieving inputs from the user
  and calling TheSwitch for the switch, until slHead is NULL.
*********/
int main()
{
	// Char* used to recieve input from the user
	char input[2];
	// Dummy used to recieve the end-of-line char
	char dummy;
	// Boolean used to know when to stop the main loop
	bool mainLoop=TRUE;
	// The type of the list
	char type;
	// The head used to point to the start of the list
	HEAD slHead=NULL;
	// The pointers used to temp save values
	ELM elm, elm2;
	// The first input
	scanf("%s", input);
	if(input[0]=='0')
	{
		type='s';
		// Allocate elm and elm2
		elm=CreateElmStr();
		elm2=CreateElmStr();
		if((elm!=NULL)&&(elm2!=NULL))
		{
			// Revieve the first element
			RecieveElement(elm, type);
			// Initializing the head
			slHead = SLCreate(elm, &CreateElmStr, &CpyElmStr, 
				&CmpElmStr, &freeElm, &PrintElmStr, &AddElmToElmStr);
		}
	}
	else if(input[0]=='1')
	{
		type='p';
		// Allocate elm and elm2
		elm=CreateElmPos();
		elm2=CreateElmPos();
		if((elm!=NULL)&&(elm2!=NULL))
		{
			// Revieve the first element
			RecieveElement(elm, type);
			// Initializing the head
			slHead = SLCreate(elm, &CreateElmPos, &CpyElmPos, 
				&CmpElmPos, &freeElm, &PrintElmPos, &AddElmToElmPos);
		}
	}
	while(slHead!=NULL)
	{
		scanf("%s", input);
		// Do the main switch
		TheSwitch(&slHead, input, type, elm, elm2);
	}
	// Free elm and elm2 at the end
	free(elm);
	free(elm2);
	return 0;
}

/*********
* function name: TheSwitch
* The Input: HEAD *slHead- the head of the list, char input[2]- input[0] is
  the current user input, char type- the type of element the list has,
  ELM elm, ELM elm2 buffers to recieve new elements.
* The Output: This is the main switch case of the program.
* The Function operation: Checks which input the user has put, then
  it recieves elements if needed and calls the appropriate function
  from the header of the GADT.
*********/
void TheSwitch(HEAD *slHead, char input[2], char type, ELM elm, ELM elm2)
{
	// Used to recieve the find result
	ELM slNode;
	// The result of the extern functions
	RESULT res;
	switch(input[0])
		{
			case 'a':
			// Revieve the new input
			RecieveElement(elm, type);
			// Add the new item into the sorted list
			res=SLAddListElement(slHead, elm);
			if(res==outOfMem)
			{
				// Memory bug, do nothing? ok..
			}
			break;

			case 's':
			RecieveElement(elm, type);
			// Find the element
			slNode=SLFindElement(*slHead, elm);
			if(slNode!=NULL)
			{
				printf("TRUE\n");
			}
			else
			{
				printf("FALSE\n");
			}
			break;

			case 'd':
			RecieveElement(elm, type);
			// Delete the element
			res=SLRemoveElement(slHead, elm);
			if(res==failure)
			{
				printf("FALSE\n");
			}
			break;

			case 'p':
			// Print the list
			PrintList(*slHead);
			break;

			case 'l':
			// Print the size of the list
			PrintSizeList(*slHead);
			break;

			case 't':
			// Recieve two elements
			RecieveTwoElements(elm, elm2, type);
			// Add to one element
			res=SLAddToElement(slHead, elm, elm2);
			if(res==outOfMem)
			{
				// Memory bug, do nothing? ok..
			}
			break;

			case 'e':
			// Destroy the list
			SLDestroy(*slHead);
			// Set the head to NULL
			*slHead=NULL;
			break;

			default:
			break;
		}
}

/*********
* function name: RecieveElement
* The Input: ELM buffer to recieve the input, char type to know the type.
* The Output: Recieves a string/pos into buffer.
* The Function operation: Simply using scanf after understanding what is
  the type.
*********/
void RecieveElement(ELM buffer, char type)
{
	// Dummy to recieve the trash
	char dummy;
	if(type=='p')
	{
		// Dummy to recieve the trash
		scanf("%c", &dummy);
		// Recieve the point into buffer->x and buffer->y
		scanf("(%d,%d)", &(((POS_T*)buffer)->x), &(((POS_T*)buffer)->y));
	}
	else if (type=='s')
	{
		// Recieve the string
		scanf("%s", buffer);
	}
}

/*********
* function name: RecieveTwoElement
* The Input: ELM buffer, ELM buffer2 to recieve two inputs, 
  char type to know what type of input.
* The Output: Recieves two string/position into buffer and buffer2.
* The Function operation: Simply using scanf after understanding what is
  the type.
*********/
void RecieveTwoElements(ELM buffer,ELM buffer2, char type)
{
	// Dummy to recieve the trash
	char dummy;
	if(type=='p')
	{
		// Dummy to recieve the trash
		scanf("%c", &dummy);
		// Recieve the point into buffer->x and buffer->y
		scanf("(%d,%d) (%d,%d)",&(((POS_T*)buffer)->x),&(((POS_T*)buffer)->y),
				&(((POS_T*)buffer2)->x),&(((POS_T*)buffer2)->y));
	}
	else if (type=='s')
	{
		// Recieve the strings
		scanf("%s %s", buffer, buffer2);
	}
}

/*********
* function name: CreateElmPos
* The Input: None
* The Output: ELM pointer to a new allocated space for a pos_t.
* The Function operation: Just mallocs enough space for pos_t.
*********/
ELM CreateElmPos()
{
	// The new Point we will have
	POS_T* newPos=(POS_T*)malloc(sizeof(POS_T));
	// return newPos at the end
	return (ELM)newPos;
}

/*********
* function name: CreateElmStr
* The Input: None
* The Output: ELM pointer to a new allocated space for a string.
* The Function operation: Just mallocs enough space for a string.
*********/
ELM CreateElmStr()
{
	// Allocate space for the new string 
	char *str=(char*)malloc(MAX_STRING_SIZE*sizeof(char));
	return (ELM)str;
}

/*********
* function name: CpyElmPos
* The Input: ELM dest to copy into, ELM src to set into dest.
* The Output: Copies src into dest.
* The Function operation: Setting the x and y of dest as the x,y of src.
*********/
void CpyElmPos(ELM dest, ELM src)
{
	// Set dest's x position as src's x
	((POS_T*)dest)->x = ((POS_T*)src)->x;
	// Set dest's y position as src's y
	((POS_T*)dest)->y = ((POS_T*)src)->y;
}

/*********
* function name: CpyElmStr
* The Input: ELM dest to copy into, ELM src to set into dest.
* The Output: Copies src into dest.
* The Function operation: Simply using strcpy
*********/
void CpyElmStr(ELM dest, ELM src)
{
	// Set *dest as *src, we should check if dest is big enough beforehand.
	strcpy((char*)dest, (char*)src);
}

/*********
* function name: CmpElmPos
* The Input: ELM first, ELM second to compare.
* The Output: >0 if first is biggeer, =0 if they are equal
  <0 if second is bigger.
* The Function operation: Calculates the size of each element,
  then it substracts them in order to find out who is bigger.
*********/
int CmpElmPos(ELM first, ELM second)
{
	// Getting the size of first
	int sizeFirst=abs(((POS_T*)first)->x)+abs(((POS_T*)first)->y);
	// Getting the size of second
	int sizeSecond=abs(((POS_T*)second)->x)+abs(((POS_T*)second)->y);
	// Return sizeFirst-sizeSecond to compare them
	return (sizeFirst-sizeSecond);
}

/*********
* function name: CmpElmStr
* The Input: ELM first, ELM second to compare between.
* The Output: >0 if first is biggeer, =0 if they are equal
  <0 if second is bigger.
* The Function operation: Simply strcmp.
*********/
int CmpElmStr(ELM first, ELM second)
{
	// Using strcmp while casting the elements to char*
	return strcmp((char*)first,(char*)second);
}

/*********
* function name: freeElm
* The Input: ELM elm to free
* The Output: Frees the element
* The Function operation: Just frees the element.
*********/
void freeElm(ELM elm)
{
	// Both elements are being freed the same way- by simply freeing them
	free(elm);
}

/*********
* function name: PrintElmPos
* The Input: ELM pos to print
* The Output: Print the position
* The Function operation: Using printf formats to print as needed.
*********/
void PrintElmPos(ELM pos)
{
	// Printing as the format specified
	printf("%.3d|%.3d\n", ((POS_T*)pos)->x,((POS_T*)pos)->y);
}

/*********
* function name: PrintElmStr
* The Input: ELM str to print
* The Output: Prints the string.
* The Function operation: Printing using printf
*********/
void PrintElmStr(ELM str)
{
	// Just print the string
	printf("%s\n", (char*)str);
}

/*********
* function name: AddElmToElmPos
* The Input: ELM pos1 to add into, ELM pos2 that will be added to pos1
* The Output: ELM pos1 with pos2 added to him
* The Function operation: Simply adding pos2 to pos1
*********/
ELM AddElmToElmPos(ELM pos1, ELM pos2)
{
	// Setting the new pos x
	((POS_T*)pos1)->x += ((POS_T*)pos2)->x;
	// Setting the new pos y
	((POS_T*)pos1)->y += ((POS_T*)pos2)->y;
	return pos1;
}

/*********
* function name: AddElmToElmStr
* The Input: ELM str1 to add to. ELM str2 that will be added to str1
* The Output: Returns ELM str1 with str2 sticked at his end.
* The Function operation: A simple strcat.
*********/
ELM AddElmToElmStr(ELM str1, ELM str2)
{
	// We use strcat to stick str2 at the end of str1
	strcat((char*)str1, (char*)str2);
	// And return it
	return str1;
}
