/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex5

******************************************/
#include "memoryAndMisc.h"
#ifndef ONETOTHREE_H
	#define ONETOTHREE_H

	void MissionOne();
	int CheckInput(char* str);
	int IsCurrentFirst(char current, char next);
	int SortString(char* str);

	void MissionTwo();
	int SubGenerator(char *str, char *sub);

	void MissionThree();
	int ShortestStr(char *str);
#endif