/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex5

******************************************/
#ifndef memoryAndMisc_H
	#define memoryAndMisc_H
	// To use boolean values more easily
	typedef unsigned char bool;
	#define TRUE 1
	#define FALSE 0

	/* 
	Memory allocation
	The reason I use this global var is to count
	and control the amount of times I use malloc
	to avoid memory leaks.
	Every time I will use malloc I will inc this global
	and every time I free memory I will dec it.
	At the end of the program the counter should be at zero.
	*/ 
	int GLOBAL_MEMORY_COUNTER;
	void* MyMalloc(int size);
	void* MyCalloc(int nItems,int sizeItems);
	void* MyFree(void* pointer);
	void CheckIfLeaked();
	char* AllocateMemory(char whatToPrint);
#endif