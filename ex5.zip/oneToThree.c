/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex5

******************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "memoryAndMisc.h"
#include "oneToThree.h"

/*********
* function name: MissionOne
* The Input: None
* The Output: Basicly the "main" of mission one.
  The center of mission 1.
* The Function operation: Asks how many chars to allocate, allocates them
  gets a string to sort, checks if it is ok input. If it is it sorts it
  and prints it.
*********/
void MissionOne()
{
	// The string we need to work with
	char *str;
	printf("Please enter how many chars to allocate:\n");
	str=AllocateMemory('r');
	if(str!=NULL)
	{
		// Allocation was ok, proceed
		printf("Please enter string to be sorted:\n");
		scanf("%s",(char *) str);
		if(CheckInput((char *)str))
		{
			// Input ok, proceed
			if(SortString((char *)str))
			{
				// Sort was ok, print the string
				printf("The string after sorting is: %s\n", str);
			}
			else
			{
				// Sort did nothing
				printf("The sting is already sorted\n");
			}
		}
		else
		{
			// Bad input
			printf("Error: Illegal input\n");
		}
	}
	else
	{
		// Allocation was bad
		printf("Error: Can not allocate Memory\n");
	}
	// Free str at the end
	MyFree(str);
}

/*********
* function name: CheckInput
* The Input: char *str to be checked
* The Output: Returns 1 if the string is sorted, 0 otherwise.
* The Function operation: It runs through the string checking if the input
  is between A-Z or a-z. If its not it returns 0. If it reaches the end it
  means the input is ok, so it returns 1
*********/
int CheckInput(char* str)
{
	while(*str!='\0')
	{
		/*
		This is working because the ascii table is placing all
		the English alphabet in this order: AB...Z ab...z
		This way we can compare each char to the end and the start
		of each serie.
		*/
		if(!(((*str>='A')&&(*str<='Z'))||((*str>='a')&&(*str<='z'))))
		{
			// Bad key
			return 0;
		}
		// Advance in the string
		str++;
	}
	return 1;
}

/*********
* function name: SortString
* The Input: char *str to be sorted
* The Output: Returns 0 if the string is already sorted, 1 if it wasnt.
* The Function operation: It does BUBBLE SORT in order to sort the string.
  it runs n times trough the n-sized char*, each time it sees that the
  current element is bigger then the next it swaps between them and it does
  that until str is sorted.
*********/
int SortString(char* str)
{
	// Indicies used for the nested loop
	int i,j;
	// Chars used to recieve to current char and the next one
	char current,next;
	// Temp used to swap between chars
	char temp;
	// Boolean used to know if we swapped between chars
	bool didSwap=FALSE;
	for(i=0;i<strlen(str);i++)
	{
		for(j=0;j<strlen(str)-1;j++)
		{
			current=*(str+j);
			next=*(str+j+1);
			if(!(IsCurrentFirst(current, next)))
			{
				// Current is not first, so we need to swap
				temp=current;
				// Current=next
				*(str+j)=next;
				// Next = temp = current
				*(str+j+1)=temp;
				// We did swap
				didSwap=TRUE;
			}
		}
	}
	// Same as typing if(didSwap) return 1 and such..
	return didSwap;
}

/*********
* function name: SortString
* The Input: char current and char next to compare
* The Output: Returns 1 if current<next and 0 otherwise
* The Function operation: It splits the problem into 4 situations
  -Current and next arent capital: return (current<next) as they are both not cpital.
  -Current and next are capital: return (current<next) as they are both cpital.
  -Current capital, next is not: return 0 as capitals are after non capital.
  -Next is capital, current is not:  return 1 as non capitals are before capitals.
*********/
int IsCurrentFirst(char current, char next)
{
	if (current<='Z')
	{
		if(next<='Z')
		{
			// Current and next are capital
			return (current<next);
		}
		else
		{
			// Current capital, next is not
			return 0;
		}
	}
	else
	{
		if(next<='Z')
		{
			// Next is capital, current is not
			return 1;
		}
		else
		{
			// Current and next are not capital
			return (current<next);
		}
	}
}

/*********
* function name: MissionTwo
* The Input: None
* The Output: Basicly the "main" of mission two.
  The center of mission 2.
* The Function operation: Asks how many chars to allocate to the two strings,
  allocates them then gets two strings and sends them to subGenerator.
  if subGenerator()==0 it means there is no concatenation, if its not print
  the value.
*********/
void MissionTwo()
{
	// The string that is being checked if hes concatenation of sub
	char *str;
	// The string that is concatenating str
	char *sub;
	// Integer used to recieve how sub is building str
	int concat;
	printf("Please enter how many chars to allocate to the two strings:\n");
	str=AllocateMemory('s');
	sub=AllocateMemory('n');
	if((str!=NULL)&&(sub!=NULL))
	{
		// Allocation was ok, proceed
		printf("Please enter two arrays of chars:\n");
		scanf("%s", str);
		scanf("%s", sub);
		// Find out if str is a concatenation of sub
		concat=SubGenerator((char *)str,(char *) sub);
		if(concat>0)
		{
			// str is indeed a concatenation of sub
			printf("%s is a concatenation of %s %d times\n", str, 
				   sub, concat);
		}
		else if(concat==0)
		{
			// str is not a concatenation of sub
			printf("No concatenation found\n");
		}
		else
		{
			// concat is -1, which means there was a memory allocation error
			printf("Error: Can not allocate Memory\n");
		}
	}
	else
	{
		// Memory Allocation was bad
		printf("Error: Can not allocate Memory\n");
	}
	// Free the strings at the end
	MyFree(str);
	MyFree(sub);
}

/*********
* function name: SubGenerator
* The Input: char *str to check if its a concenation of char *sub.
* The Output: -1 if there was a memory fail, 0 if there is no concenation
  or number of times str is concenation of sub.
* The Function operation: It creates a char *conc the will be a concenation
  of sub- each times it strcats sub into conc and then checks if conc
  is equal to str in size or bigger, if it is it stops adding sub and
  compares conc and str, if they are equal it returns the number of strcats
  used, if they are not equal it returns 0
*********/
int SubGenerator(char *str, char *sub)
{
	// To know what is the size of conc
	int size=strlen(str)+1;
	// The concenation of sub- this string will be sub multiple times
	char *conc=(char *)MyCalloc(size,sizeof(char));
	// Temp pointer used to save the value of conc when reallocing
	char *temp;
	// The counter used to count how many times sub is in str
	int conCounter=0;
	if(conc!=NULL)
	{
		// While *conc is smaller then *str
		while(strlen(conc)<strlen(str))
		{
			if(strlen(conc)+strlen(sub)<size)
			{
				// Conc is big enough, we can use strcat to add another *sub
				strcat(conc, sub);
			}
			else
			{
				// We need to increase the size of conc
				size+=strlen(str);
				// Saving the string
				temp=conc;
				// Reallocing conc to a bigger size
				conc=(char *)realloc(conc, size*sizeof(char));
				if(conc!=NULL)
				{
					// Realloc was successful, proceed
					// Put the saved value back in conc
					strcpy(conc, temp);
					// Add sub again
					strcat(conc, sub);
				}
				else
				{
					// Realloc failed, free the old conc and exit
					MyFree(temp);
					// Reallocation failed, return -1 meaning failure
					return -1;
				}
			}
			// Increase the counter as we strcat sub again
			conCounter++;
		}// end of while loop
		// We compare str and conc now to see if they are the same
		if(strcmp(str, conc)==0)
		{
			// Free conc at the end
			MyFree(conc);
			// They are the same, return counter
			return conCounter;
		}
		else
		{
			// Free conc at the end
			MyFree(conc);
			// They are not the same so str isnt a concatenation of sub, return 0
			return 0;
		}
	}// if(conc!=NULL)
	else
	{
		// Just to be sure
		MyFree(conc);
		// Allocation failed, return -1 meaning failure
		return -1;
	}
}// end of function

/*********
* function name: MissionThree
* The Input: None
* The Output: Basicly the "main" of mission three.
  The center of mission 3.
* The Function operation: Asks how many chars to allocate to the string,
  allocates them then gets a string and checks for prefixes building the string
  by calling ShortestStr. If there was no memory fails it prints the value returned.
*********/
void MissionThree()
{
	// The string we need to work with
	char *str;
	// Var used to save the output from ShortestStr
	int shortest;
	// string used to output the prefix
	char *prefix;
	printf("Please enter how many chars to allocate:\n");
	str=AllocateMemory('r');
	if(str!=NULL)
	{
		// Allocating was ok, proceed
		printf("Please enter your string:\n");
		scanf("%s", str);
		// Find the shortest string
		shortest=ShortestStr((char *)str);
		if(shortest>0)
		{
			// Output ok, change str to his prefix to print it
			*(str+shortest)='\0';
			// Print the output
			printf("The shortest prefix building the string is: %s of length %d\n"
				   ,(char *) str, shortest);
		}
		else if(shortest<0)
		{
			// Memory bug in shortestStr
			printf("Error: Can not allocate Memory\n");
		}
	}
	else
	{
		// Allocation of str was not good
		printf("Error: Can not allocate Memory\n");
	}
	// Free str at the end
	MyFree(str);
}

/*********
* function name: ShortestStr
* The Input: char *str to check for prefixes building it.
* The Output: -1 if there was a memory fail, else it returns the length
  of the shortest prefix building str.
* The Function operation: It takes each time the i prefix of str, then
  checks if SubGenerator of it is bigger then 0, if it is it stops and
  returns i to signal that we have found the wanted prefix size.
*********/
int ShortestStr(char *str)
{
	// The prefix used to check if hes building the string
	char *prefix=(char *)MyCalloc((strlen(str)+1),sizeof(char));
	// index used to run the for loop and count the length of the prefix
	int i;
	// The value from SubGenerator
	int subValue;
	if(prefix!=NULL)
	{
		// Allocating was ok, proceed
		for(i=1; i<=strlen(str); i++)
		{
			// Copy the first i chars in str into the prefix
			strncpy(prefix, str, i);
			// Check if its a concatenation
			subValue=SubGenerator(str, prefix);
			if(subValue>0)
			{
				// prefix is indeed building str, return the index
				MyFree(prefix);
				return i;
			}
			else if(subValue<0)
			{
				// Memory bug in SubGenerator, free prefix and return -1
				MyFree(prefix);
				return -1;
			}
			// If it got to here, prefix just isnt building str, try again
		}// End of for
		// If we have not returned yet, its probably a bug
		MyFree(prefix);
		return 0;
	}
	else
	{
		// Allocation for prefix failed, free it anyway and return -1
		MyFree(prefix);
		return -1;
	}
}