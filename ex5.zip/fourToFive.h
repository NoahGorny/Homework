#include "memoryAndMisc.h"
#ifndef FIVETOSIX_H
	#define FIVETOSIX_H

	void MissionFour();
	int NumOfWords(char *sentence);
	void FetchIntoSentence(char *sentence, char **words, int numWords);
	void SplitToWords(char *sentence, char **words);
	void SwapWords(char **words, int n);
	void ReverseNumWords(char *str, int n);

	void MissionFive();
	char* RecieveName(char *buffer, int *pBSize);
	int NamesInArr(char **namesArr, int totalNamesSize);
	char** InsertName(char **namesArr,int *pTotalSize, char *name);
	void PrintNames(char **names, int numOfNames, int totalNamesSize);
	bool IsNameInArr(char **names, int totalNamesSize, char *name);

	void FreeCharArr(char **charArr, int arrSize);
#endif