/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex5

******************************************/
#include "queue.h"
#include <stdio.h>
#include "memoryAndMisc.h"
#include "oneToThree.h"
#include "fourToFive.h"
int main()
{
	// Boolean used to know when to stop the main loop
	bool stopLoop=FALSE;
	// To recieve mission choice from the user
	int input;
	while(!stopLoop)
	{
		printf("Please enter your input:\n");
		scanf("%d", &input);
		switch(input)
		{
			case 0:
			// End the main loop and quit
			stopLoop=TRUE;
			break;
			case 1:
			// Do mission number one
			MissionOne();
			break;
			case 2:
			// Do mission number two
			MissionTwo();
			break;
			case 3:
			// Do mission number three
			MissionThree();
			break;
			case 4:
			// Do mission number four
			MissionFour();
			break;
			case 5:
			// Do mission number five
			MissionFive();
			break;
			case 6:
			// Do mission number six
			QueueMain();
			break;
			default:
			// Bad input, print bad input and go back to the start
			printf("Error: Illegal input\n");
			break;
		}
	}
	// Check if their was any memory leaks
	CheckIfLeaked();
	return 0;
}