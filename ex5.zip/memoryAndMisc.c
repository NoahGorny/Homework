/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex5

******************************************/
#include "memoryAndMisc.h"
#include <stdlib.h>
#include <stdio.h>

/*********
* function name: MyMalloc
* The Input: int size to malloc that size.
* The Output: void *ptr pointing to a malloc of the size.
* The Function operation: It mallocs(size), if it didnt failed it increases
  GLOBAL_MEMORY_COUNTER and returns the pointer anyway.
*********/
void* MyMalloc(int size)
{
	void* ptr=malloc(size);
	if(ptr!=NULL)
	{
		// malloc successful, increase the global
		GLOBAL_MEMORY_COUNTER++;
	}
	return ptr;
}

/*********
* function name: MyCalloc
* The Input: int nItems the amount of items, int size of each item.
* The Output: void *ptr pointing to a calloc of the (nItems,size).
* The Function operation: It callocs(nItems,size), if it didnt failed it increases
  GLOBAL_MEMORY_COUNTER, and returns the pointer anyway.
*********/
void* MyCalloc(int nItems, int sizeItem)
{
	void* ptr=calloc(nItems, sizeItem);
	if(ptr!=NULL)
	{
		// Calloc successful, increase the global
		GLOBAL_MEMORY_COUNTER++;
	}
	return ptr;
}

/*********
* function name: MyCalloc
* The Input: void* ptr to free.
* The Output: It rerurns NULL.
* The Function operation: If ptr!=NULL it decreases GLOBAL_MEMORY_COUNTER
  afterwards it frees it and returns NULL.
*********/
void* MyFree(void* ptr)
{
	if(ptr!=NULL)
	{
		// We are actually freeing stuff, dec the global
		GLOBAL_MEMORY_COUNTER--;
	}
	free(ptr);
	return NULL;
}

/*********
* function name: CheckIfLeaked
* The Input: None
* The Output: Prints error if there was missed mallocs/callocs or too many
  frees.
* The Function operation: It checks if GLOBAL_MEMORY_COUNTER>0 if it is
  it prints it, if GLOBAL_MEMORY_COUNTER<0 it prints "Bug- too many frees"
*********/
void CheckIfLeaked()
{
	if(GLOBAL_MEMORY_COUNTER>0)
	{
		// Missed mallocs/callocs
		printf("ERROR-MEMORY LEAK: %d missed mallocs/callocs\n", GLOBAL_MEMORY_COUNTER);
	}
	else if (GLOBAL_MEMORY_COUNTER<0)
	{
		// Too many Frees
		printf("BUG- too many frees\n");
	}
}

/*********
* function name: AllocateMemory
* The Input: char whatToPrint to know what to print to the user
* The Output: void* malloced pointer.
* The Function operation: It gets the wanted size of the char* from the user,
  then it mallocs the size*sizeof(char) and prints the wanted message according
  to whatToPrint.
*********/
char* AllocateMemory(char whatToPrint)
{
	// The string we will allocate intos
	char *str;
	// The size of the string
	int size;
	scanf("%d", &size);
	// Allocating the string
	str=(char *)MyMalloc((size)*sizeof(char));
	if(str!=NULL)
	{
		if(whatToPrint=='r')
		{
			// Allocation was successful
			printf("Allocated %d chars\n", size);
		}
		else if(whatToPrint=='s')
		{
			// Allocation was successful, print without \n
			printf("Allocated %d chars ", size);
		}
		else if(whatToPrint=='n')
		{
			// Allocation was successful, print addon
			printf("and %d chars\n", size);
		}
	}
	return str;
}