/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex5

******************************************/
#include "memoryAndMisc.h"
#ifndef QUEUE_H
	#define QUEUE_H
	typedef void** queue;

	void QueueMain();
	void** AddToQueue(queue que);
	void** InitializeElement();
	void** RemoveFromQueue(queue que, bool printMsg);
	void** ClearQueue(queue que, bool toPrint);
	void PrintQueue(queue que);
	void PrintMaxOrMin(queue que, char sign);
	void FindIndex(queue que);
	void PrintMenu();
#endif