/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex5

******************************************/
#include "queue.h"
#include <stdio.h>
#include "memoryAndMisc.h"
/*
How does the queue looks like:
queue is void** basicly
The pointer *queue is (int *) pointing to the current value of the first element
The pointer *(queue+1) is (void **) as he's pointing to the next element of the queue 
*/

/*********
* function name: QueueMain
* The Input: None
* The Output: Basicly the "main" of the queue interface.
  The center of mission 6.
* The Function operation: Prints the menu, asks in a loop
  for user choice input and then calls the needed function.
  At the end of the function it clears the queue to release the memory.
*********/
void QueueMain()
{
	// To know when to stop the main loop
	bool stopMainQueueLoop=FALSE;
	// To know if we should print "please select next choice" or not
	bool printNextChoice=FALSE;
	// To recieve the option the user chose
	int userChoice;
	// Print the menu
	PrintMenu();
	// The queue
	queue que=NULL;
	while(!stopMainQueueLoop)
	{
		if(printNextChoice)
		{
			printf("Please select your next choice (select 8 for complete menu)\n");
		}
		printNextChoice=TRUE;
		// Get the user input
		scanf("%d",&userChoice);
		switch(userChoice)
		{
			case 0:
			// Stop the loop and quit
			stopMainQueueLoop=TRUE;
			break;
			case 1:
			// Add item to queue
			que=AddToQueue(que);
			if(que==NULL)
			{
				// Memory bug while adding, stop queue main
				stopMainQueueLoop=TRUE;
			}
			break;
			case 2:
			// Remove item from queue
			que=RemoveFromQueue(que,TRUE);
			break;
			case 3:
			// Print the queue
			PrintQueue(que);
			break;
			case 4:
			// Print the max in the queue
			PrintMaxOrMin(que,'+');
			break;
			case 5:
			// Print the min in the queue
			PrintMaxOrMin(que,'-');
			break;
			case 6:
			// Find index of item in queue
			FindIndex(que);
			break;
			case 7:
			// Clear the queue
			que=ClearQueue(que, TRUE);
			break;
			case 8:
			// Print the menu again
			PrintMenu();
			printNextChoice=FALSE;
			break;
			default:
			// Bad input
			printf("Error: Unrecognized choice\n");
			break;
		}// End of switch
	}// End of while
	// Clear the queue at the end to release the memory
	ClearQueue(que, FALSE);
}

/*********
* function name: AddToQueue
* The Input: The queue which will be added a number.
* The Output: Queue que but with one more item added.
* The Function operation: Asks for an item value to add.
  If que is not initialized yet, initialize it.
  Afterwards it runs to the end of the que, initialize it and
  set the user input as the new element's value.
*********/
void** AddToQueue(queue que)
{
	// To recieve the item value from the user 
	int itemValue;
	// Runner used to "run" through the elements of the queue while leaving the head intact
	queue runner;
	printf("Enter item value to add\n");
	scanf("%d",&itemValue);
	if(que==NULL)
	{
		// The que is not initialized yet, initialize it
		que=InitializeElement(que);
	}
	if(que!=NULL)
	{
		runner=que;
		while(*(runner+1)!=NULL)
		{
			// Runner becomes the next element as *(runner+1) points to a void** (or NULL)
			runner=(queue)*(runner+1);
		}
		// Allocation was succesful, proceed
		// The last element is not initialized, intialize it
		*runner=MyMalloc(sizeof(int));
		*(queue)(runner+1)=InitializeElement();
		if((*runner!=NULL)&&(*(runner+1)!=NULL))
		{
			// Set the value of the last element to itemVal
			*(int *)(*runner)=itemValue;
			printf("Item %d added\n", itemValue);
		}
		else
		{
			// Memory bug
			printf("Error: Insufficient Memory\n");
			// Free all the cells
			ClearQueue(que, FALSE);
			// Set que to NULL
			que=NULL;
		}
	}
	else
	{
		// Memory bug- que is null
		printf("Error: Insufficient Memory\n");
	}
	return que;
}

/*********
* function name: InitializeElement
* The Input: The queue element which will be initialized.
* The Output: Queue element initialized.
* The Function operation: Mallocs enough space for the element.
  if the malloc was successful set the element's pointers as NULL.
*********/
void** InitializeElement()
{
	// Initialize the element
	queue element=MyMalloc(2*sizeof(void **));
	if(element!=NULL)
	{
		// And initialize his pointers
		*element=NULL;
		*(element+1)=NULL;
	}
	return element;
}

/*********
* function name: RemoveFromQueue
* The Input: The queue which one item will be removed from.
* The Output: Queue que with the first item removed.
* The Function operation: Checks if queue is empty or not.
  If its empty it frees the void ** pointer and prints "queue is empty".
  Else it sets the new head as the next element, and then frees
  the value of the old head, and then frees the old head himself.
*********/
void** RemoveFromQueue(queue oldHead, bool printMsg)
{
	// The element used to set as the new head of the queue
	queue newHead=oldHead;
	// Just to be sure that oldHead is initialized
	if((oldHead!=NULL)&&(*oldHead!=NULL))
	{
		// The new head is now the next element in the queue
		newHead=(queue)*(oldHead+1);
		if(printMsg)
		{
			printf("Item %d was removed\n", *(int *)(*oldHead));
		}
		// Now we need to free the first element's memory
		// Free the actual queue element and his value
		*oldHead=MyFree(*oldHead);
		oldHead=MyFree(oldHead);
	}
	else
	{
		newHead=MyFree(newHead);
		if(printMsg)
		{
			// Queue is empty, print an error
			printf("Error: Queue is empty!\n");
		}
	}
	return newHead;
}

/*********
* function name: PrintQueue
* The Input: The queue which will be printed.
* The Output: Prints the whole queue or error if its empty.
* The Function operation: Checks if queue is empty or not.
  If its empty it prints "queue is empty".
  Else it runs through the queue and prints each value seperated with whitespace.
*********/
void PrintQueue(queue que)
{
	// Boolean used to know if the initial queue is empty or not
	bool initialNotEmpty=(que!=NULL)&&(*que!=NULL);
	if(initialNotEmpty)
	{
		printf("Queue items are: ");
		while((que!=NULL)&&(*que!=NULL))
		{
			// Print the value of the current element
			printf("%d ", *(int *)*que);
			// Advance to the next element in the queue
			que=(queue)*(que+1);
		}
		// Go down a line at the end
		printf("\n");
	}
	else
	{
		// The queue is empty, print an error
		printf("Error: Queue is empty!\n");
	}
}


/*********
* function name: PrintMaxOrMin
* The Input: The queue which the Min/Max will be printed from.
  char sign used to determine if we need to find the max or the min:
  sign=='+': find max. sign=='-': find min.
* The Output: Prints the Min/Max of the queue or error if its empty.
* The Function operation: Checks if queue is empty or not.
  If its empty it prints "queue is empty".
  Else it runs through the queue saving the biggest/smallest item.
  At the end it prints the number as needed.
*********/
void PrintMaxOrMin(queue que, char sign)
{
	// Boolean used to know if the initial queue is empty or not
	bool initialNotEmpty=(que!=NULL)&&(*que!=NULL);
	// The max/min of the queue
	int peak;
	// The current value of the current element
	int currentVal;
	if(initialNotEmpty)
	{
		// set peak as the first value
		peak=*(int *)*que;
		while((que!=NULL)&&(*que!=NULL))
		{
			// set current as the current value
			currentVal=*(int *)*que;
			if(sign=='+')
			{
				// Search for the max
				if(currentVal>peak)
				{
					// Current is the biggest so far, set as the new peak
					peak=currentVal;
				}
			}
			if(sign=='-')
			{
				// Search for the min
				if(currentVal<peak)
				{
					// Current is the smallest so far, set as the new peak
					peak=currentVal;
				}
			}
			// Advance que to the next element
			que=(queue)*(que+1);
		}// End of while, peak is now the max/min
		if(sign=='+')
		{
			printf("Maximum item in queue is %d\n", peak);
		}
		if(sign=='-')
		{
			printf("Minimum item in queue is %d\n", peak);
		}
	}
	else
	{
		// The queue is empty, print an error
		printf("Error: Queue is empty!\n");
	}
}

/*********
* function name: FindIndex
* The Input: The queue which the wanted item index will be printed from.
* The Output: Prints the Min/Max of the queue, error if its empty
  or if the wanted item was not found.
* The Function operation: Asks for user input then checks if queue
  is empty or not. If its empty it prints "queue is empty".
  Else it runs through the queue searching for the value inserted.
  If it was found it prints the index with the counter
  that counts how many times we advanced in the queue.
  if it was not found until the end of the queue it print "item was not found".
*********/
void FindIndex(queue que)
{
	// Boolean used to know if the initial queue is empty or not
	bool initialNotEmpty=(que!=NULL)&&(*que!=NULL);
	// Boolean used to know if the item was found or not
	bool itemFound=FALSE;
	// The wanted item value
	int wantedVal;
	// The counter used to know what index we are in
	int indexCounter=1;
	if(initialNotEmpty)
	{
		printf("Please enter the item you would like to know its index\n");
		scanf("%d", &wantedVal);
		while((que!=NULL)&&(*que!=NULL))
		{
			// Chcek if the current value is equal to the wanted value
			if(wantedVal==*(int *)*que)
			{
				// We found the index, set it as true
				itemFound=TRUE;
				// Print the text
				printf("Item %d index is %d\n", wantedVal, indexCounter);			
			}
			// Advance que to the next element
			que=(queue)*(que+1);
			// Increase the counter
			indexCounter++;
		}
		if(!itemFound)
		{
			// Item was not found
			printf("Error: no such item!\n");
		}
	}
	else
	{
		// The queue is empty, print an error
		printf("Error: Queue is empty!\n");
	}
}

/*********
* function name: ClearQueue
* The Input: The queue which will be cleared, toPrint to know if we need to print
* The Output: Queue que with all the items removed.
* The Function operation: Checks if queue is empty or not.
  If its empty it just returns it.
  Else it calls RemoveFromQueue without printing the removed massages.
  Remove is setting free all the items one by one until que is clear
  (has no more items).
*********/
void** ClearQueue(queue que, bool toPrint)
{
	// Boolean used to know if the queue is empty or not
	bool notEmpty=(que!=NULL)&&(*que!=NULL);
	while(que!=NULL)
	{
		// Remove all the items from the queue without printing the removed msg
		que=RemoveFromQueue(que,FALSE);
	}
	if(toPrint)
	{
		// We need to print a msg
		if(notEmpty)
		{
			// Queue was not empty, print clear
			printf("Queue is clear\n");
		}
		else
		{
			// Queue was empty, print error
			printf("Error: Queue is empty!\n");
		}
	}
	return que;
}

/*********
* function name: PrintMenu
* The Input: None.
* The Output: It prints the full menu.
* The Function operation: It just prints the whole menu :)
*********/
void PrintMenu()
{
	printf("Please select your choice:\n");
	printf("0.Exit\n1.Add item to the queue\n");
	printf("2.Remove item from the queue\n3.Print queue\n");
	printf("4.Print the maximum item in the queue\n");
	printf("5.Print the minimum item in the queue\n");
	printf("6.Print index of given item\n");
	printf("7.Clear queue\n8.Print the menu\n");
}