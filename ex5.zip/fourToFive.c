/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex5

******************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "memoryAndMisc.h"
#include "fourToFive.h"

/*********
* function name: MissionFour
* The Input: None
* The Output: Basicly the "main" of mission four.
  The center of mission 4.
* The Function operation: Asks how many chars to allocate, then allocates.
  Later it asks for a string a num to reverse, and calls ReverseNumWords.
  Afterwards it prints the string after reverse.
*********/
void MissionFour()
{
	// The full sentence the we will later split to words
	char *sentence;
	// The number of words to reverse
	int numToReverse;
	// Dummy to recieve the \n char
	char dummy;
	printf("Please enter how many chars to allocate:\n");
	sentence=AllocateMemory('r');
	if(sentence!=NULL)
	{
		// Allocation was successful, proceed
		// Dummy to recieve the \n char
		scanf("%c", &dummy);
		printf("Please enter your string:\n");
		// Read the whole line and store it inside sentence 
		scanf("%[^\n]s",sentence);
		printf("Please enter how many words to reverse:\n");
		scanf("%d", &numToReverse);
		if(NumOfWords(sentence) >= numToReverse)
		{
			// Change the sentence by reversing the said amount of words
			ReverseNumWords(sentence, numToReverse);
			if(sentence[0]!='\0')
			{
				// Reverse was successful, print the final sentence
				printf("The string after reverse is: %s\n", sentence);
			}
			else
			{
				// Memory fail in ReverseNumWords, print error
				printf("Error: Can not allocate Memory\n");
			}
		}
		else
		{
			// There are not enough words
			printf("Error: Illegal input\n");
		}
	}
	else
	{
		// Memory fail while allocating sentence, print error
		printf("Error: Can not allocate Memory\n");
	}
	// Free sentence at the end anyway
	MyFree(sentence);
}

/*********
* function name: NumOfWords
* The Input: char *sentence to count how many word he has
* The Output: How many words are in sentence(int).
* The Function operation: Gets the length of the sentence, then runs
  through the sentence adding to a counter when there's a space or '\0'.
*********/
int NumOfWords(char *sentence)
{
	// The counter used to count how many words are there
	int counter=0;
	// Index used for the For loop
	int i;
	// To know what is the length of the sentence
	int length=strlen(sentence);
	for (i = 0; i <= length; i++)
	{
		if((sentence[i]==' ')||(sentence[i]=='\0'))
		{
			// There was a space, it means that there is a word
			counter++;
		}
	}
	return counter;
}

/*********
* function name: ReverseNumWords
* The Input: char *str to reverse, int n to know how many.
* The Output: Reverses the first n words of str
* The Function operation: It saves the sentence with a temp string, then 
  it splits the sentence to words using SplitToWords(). Later it calls
  SwapWords() in order to swap the words and then it fetches them back into
  one sentence using FetchIntoSentence().
*********/
void ReverseNumWords(char *str, int n)
{
	int i;
	// To remeber the amount of words
	int numWords=NumOfWords(str);
	// To have an "array" of all the words
	char **words=(char **)MyCalloc(numWords, sizeof(char*));
	// To save the old sentence
	char *tempStr=(char *)MyCalloc(strlen(str)+1,sizeof(char));
	if((words!=NULL)&&(tempStr!=NULL))
	{
		// Copy the sentence into tempStr
		strcpy(tempStr, str);
		// Split the sentence into words and place them inside **words
		SplitToWords(tempStr, words);
		if(words[0]!=NULL)
		{
			// Swap the words inside **words
			SwapWords(words, n);
			if(words[0]!=NULL)
			{
				// Fetch them back into the sentence
				FetchIntoSentence(str, words, numWords);
			}
			else
			{
				// Set str[0] to \0, bug in SwapWords
				str[0]='\0';
			}
		}
		else
		{
			// Set str[0] to \0, bug in SplitToWords
			str[0]='\0';
		}
	}
	else
	{
		// Set str[0] to \0, failed to allocate temp/words
		str[0]='\0';
	}
	// Free all of **words
	FreeCharArr(words, numWords);
	// Free temp
	MyFree(tempStr);
}

/*********
* function name: SwapWords
* The Input: char **array of words to swap. int n to know how many to swap.
* The Output: Swaps the first n words inside words.
* The Function operation: Loops n/2 times swapping between the [i] element
  and the [n-1-i] element.
*********/
void SwapWords(char **words, int n)
{
	// Index for the For loop
	int i;
	// Temp char* to swap between chars
	char *temp;
	for(i=0; i<(n/2); i++)
	{
		// swapping between words[i] and words[n-1-i]
		temp=words[i];
		words[i]=words[n-1-i];
		words[n-1-i]=temp;
	}
}

/*********
* function name: FetchIntoSentence
* The Input: char *sentence to put the words into, char **array of words 
  to fetch into the sentence. int numWords to know how many words are there
  inside **words
* The Function operation: Loops numWords times each time strcating the word
  into sentence and adding space afterwards.
*********/
void FetchIntoSentence(char *sentence, char **words, int numWords)
{
	// To know the true length of the sentence
	int trueLen=strlen(sentence);
	// "Delete" what was in sentence before
	sentence[0]='\0';
	// To what is the current length
	int senLen;
	// Index for the For loop
	int i;
	for(i=0; i<numWords; i++)
	{
		// Copy the word into the sentence
		strcat(sentence, words[i]);
		// Add space if needed
		senLen=strlen(sentence);
		if(senLen<trueLen)
		{
			sentence[senLen]=' ';
			// New end-of-line
			sentence[senLen+1]='\0';
		}
	}

}

/*********
* function name: SplitToWords
* The Input: char *sentence to split, char **array of words to 
  put the words into.
* The Function operation: strtoking the sentence and then putting each
  token inside **words
*********/
void SplitToWords(char *sentence, char **words)
{
	// Token to run through the string
	char *token;
	// Get the first token
	token=strtok(sentence, " ");
	// Counter to remember on what word we are in
	int wordCounter=0;
	while(token!=NULL)
	{
		// Assign the correct space for word number i
		words[wordCounter]=MyCalloc((strlen(token)+1),sizeof(char));
		if(words[wordCounter]!=NULL)
		{
			// Allocation was successful, Copy the token into the word
			strcpy(words[wordCounter], token);
			// Advance to the next word
			token=strtok(NULL, " ");
			wordCounter++;
		}
		else
		{
			// Memory bug, set words[0]='\0' and exit the while loop
			words[0]=NULL;
			token=NULL;
		}
	}
}

/*********
* function name: MissionFive
* The Input: None
* The Output: Basicly the "main" of mission five.
  The center of mission 5.
* The Function operation: Asks in loop for a name until it recieves "QUIT"
  It places each name in a sorted "array" of names using InsertName.
  At the ends it prints the full array.
  Also in order to recieve to names, it places each new input inside
  buffer, char by char in order to know if we need to realloc.
*********/
void MissionFive()
{
	// The current total size of **names
	int totalNamesSize=10;
	// A pointer to names size
	int *pTotalSize=&totalNamesSize;
	// The names "array" we will be using 
	char **names=(char **)MyCalloc(totalNamesSize, sizeof(char*));
	// Counter used to count how many names are there
	int numOfNames=0;
	// Boolean used to know when to stop the names loop
	bool stopNames=FALSE;
	// Boolean used to know whther to print the names or not
	bool printNames=TRUE;
	// Integer to save the buffer size
	int bSize=10;
	// A pointer to the bufferSize
	int *pBSize=&bSize;
	// The buffer used to temp save words
	char *buffer=(char *)MyMalloc(bSize*sizeof(char));
	// Dummy used to recieve \n
	char dummy;
	if((buffer!=NULL)&&(names!=NULL))
	{
		// Allocation was ok, proceed
		printf("Please enter list of names:\n");
		// Dummy used to recieve \n
		scanf("%c", &dummy);
		while(!stopNames)
		{
			// Recieving a word and saving it inside buffer
			buffer=RecieveName(buffer, pBSize);
			if(buffer!=NULL)
			{
				if(strcmp(buffer, "QUIT")!=0)
				{
					// Insert the name into the array
					names=InsertName(names, pTotalSize, buffer);
					if(names!=NULL)
					{
						// Allocation was ok
						numOfNames++;
					}
					else
					{
						// Memory bug in InsertName
						printf("Error: Cannot allocate Memory\n");
						// Stop the loop and dont print at the end
						stopNames=TRUE;
						printNames=FALSE;
					}
				}
				else
				{
					// "QUIT" was typed in, stop the loop
					stopNames=TRUE;
				}
			}
			else
			{
				// Memory bug in RecieveName
				printf("Error: Cannot allocate Memory\n");
				// Stop the loop and dont print at the end
				stopNames=TRUE;
				printNames=FALSE;
			}
		}// End of while
		if(printNames)
		{
			// Print names at the end
			PrintNames(names, numOfNames, totalNamesSize);
		}
	}
	else
	{
		// Memory bug allocating buffer/names
		printf("Error: Cannot allocate Memory\n");
	}
	// Free all of names and buffer
	FreeCharArr(names, totalNamesSize);
	MyFree(buffer);

}

/*********
* function name: RecieveName
* The Input: char *buffer to recive to name into, int *pBSize pointer to
  the buffer size.
* The Output: buffer with string inside it.
* The Function operation: It gets a char from the input and sets it inside
  buffer, if there is no space it reallocs buffer and keeps on going until
  there is a space or \n to end the word.
*********/
char* RecieveName(char *buffer, int *pBSize)
{
	// Temp to save buffer in case realloc fails
	char *temp;
	// Index to access each char of buffer
	int index=0;
	// Char to recieve the name char by char
	char ch = '\n';
	while(ch!='\0')
	{
		ch=getc(stdin);
		if((ch==' ')||(ch=='\n')||(ch==EOF))
		{
			// We need to stop
			ch='\0';
		}
		if(*pBSize <= index)
		{
			// We need to increase the buffer
			*pBSize+=5;
			// Reallocing to a bigger size
			temp=(char *)realloc(buffer, (*pBSize)*(sizeof(char)));
			if(temp!=NULL)
			{
				// Realloc was ok
				buffer=temp;
			}
			else
			{
				// Realloc failed, free old buffer and return NULL
				MyFree(buffer);
				return NULL;
			}
		}
		// Store the char and increase the index
		buffer[index]=ch;
		index++;
	}// End of while
	// Return buffer at the end
	return buffer;
}

/*********
* function name: NamesInArr
* The Input: char **namesArr to count for names, int totalNamesSize to
  know the size of the array.
* The Output: Returns how many names are actually in namesArr
* The Function operation: It runs through namesArr, when it sees a NULL
  it stops and returns the counter (as there are no more words), if there
  are no NULLs it means namesArr is full so it returns totalNAmesSize
*********/
int NamesInArr(char **namesArr, int totalNamesSize)
{
	// Counter used to count how many words are there
	int counter;
	for(counter=0; counter<totalNamesSize; counter++)
	{
		if(namesArr[counter]==NULL)
		{
			// names[counter] isnt a word
			return counter;
		}
	}
	// namesArr is full of words
	return totalNamesSize;
}

/*********
* function name: InsertName
* The Input: char **namesArr to insert into, int *pTotalSize pointer 
  to the arr size and char *name to insert.
* The Output: Returns namesArr with name inserted into it.
* The Function operation: It checks with IsNameInArr() if the name already
  exists in the array, if it is it stops and returns the array recieved.
  If not it checks if there is enough space for another string, if not
  it reallocs namesArr to a bigger size. Afterwards it inserts name into
  the array using BUBBLE INSERTION. Basicly it checks each time if name
  is bigger then namesArr[i-1], if it is it places it in namesArr[i].
  If its smaller it moves namesArr[i-1] into namesArr[i] and does i--
*********/
char** InsertName(char **namesArr,int *pTotalSize, char *name)
{
	// Temp char** to save namesArr in case realloc fails
	char **oldSaver;
	// Temp to save the name name somewhere
	char *temp;
	// Index used to run through the array
	int index;
	// Integer used to know how many names are actually in **namesArr
	int numWords=NamesInArr(namesArr, *pTotalSize);
	// The place name should go in
	int place=0;
	// Boolean used to know if we found the place of name already or not
	bool foundPlace=FALSE;
	if(!IsNameInArr(namesArr, *pTotalSize, name))
	{
		// The name isnt inside namesArr, proceed
		if(numWords>=*pTotalSize)
		{
			// We need to increase the size of **namesArr
			*pTotalSize+=5;
			oldSaver=(char **)realloc(namesArr, (*pTotalSize)*sizeof(char *));
			if(oldSaver!=NULL)
			{
				// Realloc was ok, proceed
				namesArr=oldSaver;
				// Set the new junk chars * to NULL
				for (index = numWords; index < *pTotalSize; index++)
				{
					namesArr[index]=NULL;
				}
				
			}
			else
			{
				// Realloc failed, free the array and return NULL
				FreeCharArr(namesArr, (*pTotalSize)-5);
				return NULL;
			}
		}
		// Initialize temp
		temp=(char *)MyCalloc(strlen(name)+1, sizeof(char));
		// Copy name into temp
		strcpy(temp, name);
		for(index=numWords; (index>0)&&(!foundPlace); index--)
		{
			if(strcmp(name, namesArr[index-1])>0)
			{
				// Name is bigger than the current name[i-1], we have found his place
				foundPlace=TRUE;
				// Set place as the index of the right place
				place=index;
			}
			else
			{
				// Name is smaller, we need to keep searching
				namesArr[index]=namesArr[index-1];
			}
		}
		// place=0 if no place has been found (he is the smallest)
		namesArr[place]=temp;
	}
	return namesArr;
}

/*********
* function name: IsNameInArr
* The Input: char **names to search for a name, int totalNamesSize to
  know the size of the array, char *name to search.
* The Output: True if the name exists in **names, False if it doesnt.
* The Function operation: It runs through namesArr, if it founds an
  element that is equal to name, return True. If it doesnt find one
  it returns True.
*********/
bool IsNameInArr(char **names, int totalNamesSize, char *name)
{
	// Index used to run through **names
	int i;
	// Actual names in names
	int actualNames=NamesInArr(names, totalNamesSize);
	for(i=0; i<actualNames; i++)
	{
		if(strcmp(names[i], name)==0)
		{
			// The name is alraedy inside the arr
			return TRUE;
		}
	}
	// The name isnt in the arr
	return FALSE;
}

/*********
* function name: PrintNames
* The Input: char **names to print, int totalNamesSize to
  know the size of the array, int numOfNames to print as the amount of names.
* The Output: Prints all the names in **names.
* The Function operation: It runs through names, printing each name until
  there is no more names.
*********/
void PrintNames(char **names, int numOfNames, int totalNamesSize)
{
	// Index used for the For loop
	int i;
	// Integer used to know how many names are there in **names
	int actualNames=NamesInArr(names, totalNamesSize);
	printf("There are %d names:\n", numOfNames);
	for(i=0; i < actualNames; i++)
	{
		printf("%s\n", names[i]);
	}
}

/*********
* function name: FreeCharArr
* The Input: char **names to free, int arrSize to
  know the size of the array.
* The Output: Prints all the names in **names.
* The Function operation: It runs through charArr, freeing each element and
  freeing charArr at the end.
*********/
void FreeCharArr(char **charArr, int arrSize)
{
	// Index used to use the For loop
	int i=0;
	if(charArr!=NULL)
	{
		for(i=0; i< arrSize; i++)
		{
			// Free each word
			MyFree(charArr[i]);
		}
	}
	// Free the final sentence
	MyFree(charArr);
}