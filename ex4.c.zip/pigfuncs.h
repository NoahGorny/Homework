/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex4

******************************************/
#ifndef PIGFUNCS_H
	#define PIGFUNCS_H
	#ifndef BOOLEAN_GUARD
		#define BOOLEAN_GUARD
		// To make boolean values more clear
		typedef enum boolean {false=0, true=1} bool;
	#endif
	// The maximum size of a pig latin sentence
	#define SENTENCE_SIZE 125
	// The maximum size of each word(including way at the end)
	#define WORD_SIZE 18
	void PigLatin();
	void TranslateWord(char word[]);
	void LowerCase(char sentence[]);
	void BreakToWords(char sentence[]);
	void AddWord(char pigSentence[], char word[]);
	bool IsVowel(char character);
	void RotateLeft(char word[]);

#endif