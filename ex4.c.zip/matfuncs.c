/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex4

******************************************/
#include <stdio.h>
#include "matfuncs.h"

/*
Because every function requires row and col, the most
reasonable thing was to give them their pointers so they could
change the matrix dimentions inside the function, but we cant yet
so it got a little bit clumsy :(
*/

/*********
* function name: MatrixCalculator
* The Input: None
* The Output: Basicly the "main" of the matrix calculator.
  The center of mission 1.
* The Function operation: Asks for the first matrix input
  and then calls the operations function to start the operations loop.
*********/
void MatrixCalculator()
{
	// Controls the main loop of the calculator
	bool calculatorLoop=true;
	// The main matrix, all the opretions is on her
	int theMatrix[SIZE][SIZE];
	// The number of the rows and columns of the main matrix, respectievly
	int numRows,numCol;
	printf("Welcome to the Matrix calculator\n");
	// Main calculator loop
	while(calculatorLoop)
	{
		printf("Please enter first matrix dimensions (row col):\n");
		// Sets the dimensions
		scanf("%d %d",&numRows,&numCol);
		if((numRows<=0)||(numCol<=0))
		{
			// Bad input, return to the start
			printf("Error\n");
		}
		else
		{
			// Input ok, call InputMat
			InputMat(theMatrix, numRows, numCol);
			/* 
			Starts the loop of asking for operations, and at the end
			returns true/false- true if clear was pressed
			(to ask for a new matrix) or false if quit was pressed.
			*/
			calculatorLoop=AskForOperations(theMatrix, numRows, numCol);
		}// Else
	}// Main loop 
}// func

/*********
* function name: InputMat
* The Input: int mat[][] to put stuff into, number of rows and columns
* The Output: Sets mat[][] with the user's input.
* The Function operation: Asks for numbers and sets them
  as elements as needed.
*********/
void InputMat(int mat[SIZE][SIZE], int numRows, int numCol)
{
	printf("Please enter matrix elements(%dx%d):\n", numRows, numCol);
	// indicies used to operate the nested loop
	int i,j;
	for(i = 0; i < numRows; i++)
	{
		for (j = 0; j < numCol; j++)
		{
			// Gets the i * numRows + j element and sets him in place
			scanf("%d", &mat[i][j]);
		}
	}
}

/*********
* function name: AskForOperations
* The Input: int theMat[][], number of rows and columns
* The Output: depends on user input.
  +,-,q,t- calls the correct function and asks for another input.
  q- returns false (which means it will stop the calculator)
  c- returns true so another firstMatrix will be inserted.
  default- Bad key, asks again.
* The Function operation: Asks for operators in a loop and
  calls the appropriate function.
*********/
bool AskForOperations(int theMat[SIZE][SIZE], int numRows, int numCol)
{
	// The char to recieve the operation
	char op;
	// Dummy to get rid of the end-of-line char
	char dummy;
	// To help us swap
	int temp;
	// Number of column of the second matrix in mult
	int secondCol;
	// To loop input of mult column
	bool getColumn;
	// This should run until q or c are pressed
	while(true)
	{
		// To use inside mult call loop
		getColumn=true;
		printf("Please enter operation:(+,-,*,t,c,q)\n");
		// Dummy to get rid of the end-of-line char
		scanf("%c",&dummy);
		scanf("%c",&op);
		switch(op)
		{
			case '+':
			// Call the addOrSub function with '+' sign
			AddOrSubMat(theMat, numRows, numCol, '+');
			break;
			case '-':
			// Call the addOrSub function with '-' sign
			AddOrSubMat(theMat, numRows, numCol, '-');
			break;
			case '*':
			while(getColumn==true)
			{
				// Gets the number of columns of the second matrix
				printf("Please enter column dimension of second matrix:\n");
				scanf("%d", &secondCol);
				if(secondCol<=0)
				{
					// Bad input, try again
					printf("Error\n");
				}
				else
				{
					// Input ok, proceed
					getColumn=false;
				}
			}
			// Call the mult function
			MultMat(theMat, numRows, numCol, secondCol);
			// The number of columns is num of rows in the second matrix
			numCol=secondCol;
			break;
			case 't':
			// call the transpose function
			TransposeMat(theMat, numRows, numCol);
			// We need to swap numRows and numCol
			temp=numCol;
			numCol=numRows;
			numRows=temp;
			break;
			case 'c':

			/* 
			We need to get a new first matrix.
			exit this operation loop (the function) but
			return true to keep the main loop running.
			*/

			return true;
			break;
			case 'q':

			/*
			We need to stop the whole show.
			return false to stop the main loop (and this function)
			*/

			return false;
			break;
			default:
			// Bad key, repeat
			printf("This operation does not exist!\n");
			break;
		}
	}
}

/*********
* function name: MultMat
* The Input: int mat[][] to mult, number of rows and columns
  of the first matrix and number of columns of the second metrix
  (num of rows is just the num of col in the first matrix)
* The Output: Multiply mat[][] with the second matrix, print it
  and sets the multipication matrix as mat[][]. 
* The Function operation: Asks for second matrix input and then
  multiply the first matrix and the second using nested loops.
*********/
void MultMat(int mat[SIZE][SIZE], int numRows, int numCol, int secondCol)
{
	// Indicies used for the nested loops
	int i,j,k;
	// The second matrix used to mult
	int secondMat[SIZE][SIZE];
	// The sums matrix used to save the changes
	int sumMat[SIZE][SIZE];
	// Number of rows in the second is equal to numCol in the first one
	int secondRows=numCol;
	// Calls InputMat to get the second matrix elements
	InputMat(secondMat, secondRows, secondCol);
	// The sum of each row*col
	int sum;
	// For each row in the first matrix, do the following:
	for (i = 0; i < numRows; i++)
	{
		// For each column in the second matrix
		for(j = 0; j < secondCol; j++)
		{
			// make sum 0 again to use with the next row*col
			sum=0;
			/*
			numCol=secondRows so we can use both
			run through the whole row(first) and col(second) and add
			to sum their multipication.
			*/
			for(k = 0; k < numCol; k++)
			{
				sum+=mat[i][k]*secondMat[k][j];
			}
			// Afterwards, set the value to sumMat in the right place
			sumMat[i][j]=sum;
		}// End of columns, go down a line in rows
	}// End of the process
	// Change mat to the multipication matrix
	for (i = 0; i < numRows; i++)
	{
		for (j = 0; j < secondCol; j++)
		{
			// Set each element as the element in sumMat
			mat[i][j]=sumMat[i][j];
		}
	}
	// print it and return
	PrintMat(mat, numRows, secondCol);
	/*
	We need to remember that numRows and numCol havn't changed.
	So we need to change them in the operation loop (askForOperation)
	*/
}

/*********
* function name: AddOrSubMat
* The Input: int mat[][] to interact with and change,
  number of rows/columns and char sign to know to add or to sub
* The Output: prints the addition/substraction and set it as the
  value of mat.
* The Function operation: Asks for a second matrix, and then
  with nested loops we add_sub one element at a time.
*********/
void AddOrSubMat(int mat[SIZE][SIZE], int numRows, int numCol, char sign)
{
	// The second matrix used to add/sub
	int secondMat[SIZE][SIZE];
	// Indicies used for the nested loop
	int i,j;
	// Asks for second matrix input, she has same number of row/col
	InputMat(secondMat, numRows, numCol);
	for(i = 0; i < numRows; i++)
	{
		for(j = 0; j < numCol; j++)
		{
			if(sign=='+')
			{
				// setting mat as the addition
				mat[i][j]+=secondMat[i][j];
			}
			if(sign=='-')
			{
				// setting mat as the substraction
				mat[i][j]-=secondMat[i][j];
			}
		}
	}
	// End of operation, print the newly accuaired matrix
	PrintMat(mat, numRows, numCol);
}

/*********
* function name: TransposeMat
* The Input: int mat[][] to transpose, number of rows and columns
* The Output: transpose mat and prints it- numRows and
  numCol REMAINS THE SAME and are changed directly after this func.
* The Function operation: Inside the nest loop, swaps between
  mat[i][j] and mat[j][i]. If i!=j, some of the values
  are useless, but it doesnt matter as long as numRows and
  numCol are currect.
*********/
void TransposeMat(int mat[SIZE][SIZE], int numRows, int numCol)
{
	// Indicies used for the nested loops
	int i,j;
	// To help us swap
	int temp;
	// We need to know if there are more rows or columns
	bool moreRows= numRows > numCol;
	for (i = 0; i < numRows; i++)
	{
		for(j = 0; j < numCol; j++)
		{
			// There are two options to scan, top right to down left
			if(((i<j)&&!(moreRows))||((j<i)&&(moreRows)))
			{
				if((j<numRows)&&(i<numCol))
				{
					// mat[j][i] is ok, can be used
					temp=mat[j][i];
				}
				else
				{
					// mat[j][i] is junk, we dont really need him
					temp=0;
				}
				// swapping
				mat[j][i]=mat[i][j];
				mat[i][j]=temp;
			}
		}
	}
	// Printing with rows and columns swapped
	PrintMat(mat , numCol, numRows);
}

/*********
* function name: PrintMat
* The Input: int mat[][] to put print, number of rows and columns
* The Output: prints the matrix.
* The Function operation: nested loops to print as needed.
*********/
void PrintMat(int mat[SIZE][SIZE], int numRows, int numCol)
{
	// Indicies used for the nested loop
	int i,j;
	printf("The answer is:\n");
	for (i = 0; i < numRows; i++)
	{
		for(j = 0; j < numCol; j++)
		{
			// Each element has spacing of 4 to the right
			printf("%4d", mat[i][j]);
		}
		// End of row, go down a line
		printf("\n");
	}
}