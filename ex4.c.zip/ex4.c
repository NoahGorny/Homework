/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex4

******************************************/
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "matfuncs.h"
#include "pigfuncs.h"

int main()
{
	// Boolean to know when to stop the main program loop
	bool stopMain=false;
	// To recieves the input order
	char firstOrder[WORD_SIZE];
	// Index used in for loops
	int i;
	while(stopMain==false)
	{
		printf("Main menu, choose between the options:\n");
		printf("Matrix Calculator\nPigLatin Translator\n");
		scanf("%s", &firstOrder);
		// Make it all lower case
		LowerCase(firstOrder);
		if(strcmp(firstOrder,"calculator")==0)
		{
			// Call the "main" func of matrixCalculator
			MatrixCalculator();
		}
		else
		{
			if(strcmp(firstOrder,"translator")==0)
			{
				// Call the "main" func of the translator
				PigLatin();
			}
			else
			{
				if(strcmp(firstOrder,"quit")==0)
				{
					// We need to quit, stop the loop
					stopMain=true;
				}
				else
				{
					// Not an option, print error and ask for input again
					printf("This was not an option.\n");
				}
			}
		}
	}// main loop
	return 0;
}