/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex4

******************************************/
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "pigfuncs.h"

/*********
* function name: PigLatin
* The Input: None
* The Output: Basicly the "main" of the PigLatin translator.
  The center of mission 2.
* The Function operation: Asks for a sentence, LowerCase it,
  sends it to the proccessor and then prints it.
  Afterwards it asks for another input.
*********/
void PigLatin()
{
	// The string used to recieve a sentence
	char theSentence[SENTENCE_SIZE];
	// Dummy used to recieve the /n
	char dummy;
	// Saves the choice of another sentence
	char choice;
	// Bo
	bool anotherWord=true;
	while(anotherWord)
	{
		printf("Please enter a sentence in English:\n");
		// Dummy to get rid off the \n input
		scanf("%c", &dummy);
		fgets(theSentence,SENTENCE_SIZE,stdin);
		// Make the sentence all lower case
		LowerCase(theSentence);
		// Break into words and translate each one to PigLatin
		BreakToWords(theSentence);
		// Print the translated sentence
		puts(theSentence);
		printf("Do you want to translate another sentence?(y/n)\n");
		scanf("%c", &choice);
		if(choice=='y')
		{
			// Does nothing and continue the while loop
		}
		if(choice=='n')
		{
			// Ends the while loop
			anotherWord=false;
		}
	}
}

/*********
* function name: BreakToWords
* The Input: char sentence[] which is the main sentence.
* The Output: Changes the sentence into a PigLatin sentence.
* The Function operation: It breaks the sentence into words and then
  sends each word to the word translator.
*********/
void BreakToWords(char sentence[])
{
	// The string used to manipulate each word
	char word[WORD_SIZE];
	// The PigLating sentence that sentence will be set as "null"
	char pigSentence[SENTENCE_SIZE]={0};
	// Pointer used to know where a new word is located
	char *token;
	// get the first token
	token = strtok(sentence, " \t\n");
	// walk through other tokens
	while( token != NULL ) 
	{
		// Copy the word into our word string
		strcpy(word, token);
		// Translate the word to PigLatin
		TranslateWord(word);
		// Add the word to pigSentence
		AddWord(pigSentence, word);
		// Gets the next word
		token = strtok(NULL, " \t\n");
	}
	// Sets sentence to pigSentence
	strcpy(sentence, pigSentence);
}

/*********
* function name: LowerCase
* The Input: char sentence[].
* The Output: Makes the sentence all LowerCase letters.
* The Function operation: Loops through the sentence and uses toLower
  on each letter.
*********/
void LowerCase(char sentence[])
{
	// To use with the for loop
	int i;
	for(i = 0; sentence[i]; i++)
	{
		// Changes the letter to LowerCase
  		sentence[i] = tolower(sentence[i]);
	}
}

/*********
* function name: TranslateWord
* The Input: char word[]
* The Output: Translate the word into pig latin using the correct syntax.
* The Function operation: Checks if the first letter is a vowel,
  if it is it just adds "way" to the end.
  If its not it loops by rotating the word left until it sees
  a vowel or reached the end of the word, then it adds "ay" to the end.
*********/
void TranslateWord(char word[])
{
	// To add "way" to the end
	char charWay[4]="way";
	// To add "ay" to the end
	char charAy[3]="ay";
	// To know if the word is finished
	int len=0;
	// To get the first char in the word
	char firstChr=word[0];
	// Checks if the first char is a vowel, not including 'y'
	if((firstChr=='a')||(firstChr=='e')||(firstChr=='i')||(firstChr=='o')||(firstChr=='u'))
	{
		// Add "way" to the end and finish
		strcat(word, charWay);
	}
	else
	{
		while((len<strlen(word))&&(IsVowel(word[0])==false))
		{
			// Puts the first char at the end
			RotateLeft(word);
			len++;
		}
		// Add "ay" to the end
		strcat(word, charAy);
	}
}

/*********
* function name: AddWord
* The Input: char pigSentence[], char word[] to add
* The Output: Adds the words to the end of the sentence,
  and adds whitespace if possible.
* The Function operation: uses strcat then checks if there is space
  for a whitespace, if there is he puts whitespace at the end.
*********/
void AddWord(char pigSentence[], char word[])
{
	// Copy the word
	strcat(pigSentence, word);
	if(strlen(pigSentence)+1<SENTENCE_SIZE)
	{
		// If there is space, add a Whitespace
		pigSentence[strlen(pigSentence)]=' ';
	}
}

/*********
* function name: IsVowel
* The Input: char chr
* The Output: True if it is a vowel, false if it isn't.
* The Function operation: Using alot of Or operators, it checks if the char
  is: 'a', 'e', 'i', 'o', 'u', 'y' or not.
*********/
bool IsVowel(char chr)
{
	return (chr=='a')||(chr=='e')||(chr=='i')||
		   (chr=='o')||(chr=='u')||(chr=='y');
}

/*********
* function name: RotateLeft
* The Input: char word[] to rotate
* The Output: Rotates the word left by moving every char one place left
  and setting the last one as the old first one.
* The Function operation: Saves the first char, loops through the word
  moving each char one place to the left and at the end sets the 
  old first as the last one.
*********/
void RotateLeft(char word[])
{
	// To help with the swap
	char temp=word[0];
	// To use in the for loop
	int i;
	for (i = 0; i < strlen(word) - 1; i++)
	{
		// Swaps each char with the char after it, except the last char
		word[i]=word[i+1];
	}
	// At the end, put the old word[0] at the end of the string
	word[strlen(word)-1]=temp;
}

