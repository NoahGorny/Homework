/******************************************

*Student Name: Noah Gorny

*Student ID: 209399757

*Course Exercise Group: 02 Math

*Exercise name: ex4

******************************************/
#ifndef MATFUNCS_H
	#define MATFUNCS_H
	#ifndef BOOLEAN_GUARD
		#define BOOLEAN_GUARD
		// To make boolean values more clear
		typedef enum boolean {false=0, true=1} bool;
	#endif
	// The maximum size of each matrix
	#define SIZE 15
	void MatrixCalculator();
	void InputMat(int mat[SIZE][SIZE], int numRows, int numCol);
	bool AskForOperations(int mat[SIZE][SIZE], int numRows, int numCol);
	void MultMat(int mat[SIZE][SIZE], int numRows, int numCol, int secondCol);
	void AddOrSubMat(int mat[SIZE][SIZE], int numRows, int numCol, char addOrSub);
	void TransposeMat(int mat[SIZE][SIZE], int numRows, int numCol);
	void PrintMat(int mat[SIZE][SIZE], int numRows, int numCol);
#endif
